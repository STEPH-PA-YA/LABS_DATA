import io
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors

def generate_maintenance_pdf(programacion):
    """
    Generate a PDF with the details of a completed maintenance task.
    
    Parameters:
    programacion (tuple): A tuple containing the following information:
        0. Programación ID
        1. Equipment name
        2. Maintenance type
        3. Year
        4. Month
        5. Performed by
    
    Returns:
    bytes: The generated PDF file as bytes.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    data = [
        ["Equipo:", programacion[1]],
        ["Maintenance Type:", programacion[2]],
        ["Year:", programacion[3]],
        ["Month:", programacion[4]],
        ["Performed by:", programacion[5]]
    ]

    table = Table(data)
    style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.grey),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 14),
        ('BOTTOMPADDING', (0,0), (-1,0), 12),
        ('BACKGROUND', (0,1), (-1,-1), colors.beige),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ])

    table.setStyle(style)
    elements.append(table)

    doc.build(elements)

    pdf_data = buffer.getvalue()
    buffer.close()
    return pdf_data