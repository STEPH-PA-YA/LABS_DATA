# LABS_DATA
Este es un proyecto enfocado a consolidado y manejo de información de laboratorios y equipos - Para: Practicas profesionales
